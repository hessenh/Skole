#include <stdio.h>
#include <stdlib.h>

int
main ( int argc, char **argv )
{
    printf ( ")This is going to create " );
    printf ( "some problems(\n" );
    exit ( EXIT_SUCCESS );
}
