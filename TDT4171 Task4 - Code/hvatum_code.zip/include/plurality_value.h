/*
 * plurality_value.h
 *
 *  Created on: Mar 4, 2012
 *      Author: stian
 */

#ifndef PLURALITY_VALUE_H_
#define PLURALITY_VALUE_H_

#include "types.h"

int
plurality_value(obj** examples, int num_examples);

#endif /* PLURALITY_VALUE_H_ */
