/*
 * main.h
 *
 *  Created on: Mar 4, 2012
 *      Author: stian
 */

#ifndef MAIN_H_
#define MAIN_H_




#endif /* MAIN_H_ */
